# DERİN 2.0 — Android v0.4

APK derlemeye hazır Android Studio/AIDE kaynak projesidir.

## Bu sürüm
- Karanlık sohbet arayüzü
- Türkçe sesli giriş ve Türkçe sesli okuma
- Kalıcı yerel sohbet geçmişi (son 50 mesaj)
- Uygulama içinden API anahtarı ekleme/silme
- API anahtarını kaynak koda gömmez
- Gerçek AI bağlantısı için OpenAI Chat Completions API
- API anahtarı yokken yerel cevap modu
- Sohbeti temizleme
- API/bağlantı hatalarında kullanıcıya anlaşılır durum mesajları
- Sesli giriş sırasında yaşam döngüsü temizliği

## APK oluşturma
Android Studio ile klasörü aç, Gradle senkronizasyonunu tamamla ve `Build > Build APK(s)` seç.

Debug APK yolu: `app/build/outputs/apk/debug/app-debug.apk`

AIDE ile de Gradle tabanlı proje olarak açılabilir.

## API anahtarı
Uygulama içindeki ⚙ menüsünden kendi API anahtarını gir. Anahtar cihazın uygulama özel SharedPreferences alanında tutulur; kaynak koda veya APK içine sabitlenmez.

> Not: Mobil APK içine doğrudan gizli API anahtarı gömmek güvenli değildir. Üretim kullanımında bir backend/proxy tercih edilmelidir.
