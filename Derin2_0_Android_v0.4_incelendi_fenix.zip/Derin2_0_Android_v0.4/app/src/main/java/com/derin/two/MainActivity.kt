package com.derin.two

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var input: EditText
    private lateinit var chat: TextView
    private lateinit var status: TextView
    private lateinit var scroll: ScrollView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var lastReply = ""
    private val history = mutableListOf<Pair<String, String>>()
    private val prefs by lazy { getSharedPreferences("derin", MODE_PRIVATE) }
    private val persona = "Sen Derin 2.0'sun. Kullanıcıyla aynı tarafta çalışan ikinci zihinsin. Türkçe konuş. Yapmacık, aşırı resmi veya üçüncü şahıs anlatımı kullanma. Güçlü, sakin, net ve gerektiğinde karşı çıkan bir dost gibi cevap ver. Kullanıcıya zarar verme, yasa dışı işlere yönlendirme veya tehdit üretme."

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        input = findViewById(R.id.input); chat = findViewById(R.id.chat); status = findViewById(R.id.status); scroll = findViewById(R.id.scroll)
        tts = TextToSpeech(this, this)
        findViewById<Button>(R.id.send).setOnClickListener { send() }
        findViewById<Button>(R.id.speak).setOnClickListener { speakLast() }
        findViewById<Button>(R.id.mic).setOnClickListener { startVoice() }
        findViewById<Button>(R.id.settings).setOnClickListener { showSettings() }
        findViewById<Button>(R.id.clear).setOnClickListener { clearChat() }
        input.setOnEditorActionListener { _, action, _ -> if (action == EditorInfo.IME_ACTION_SEND) { send(); true } else false }
        loadHistory()
        if (history.isEmpty()) { render("DERİN", "Buradayım kuzen. Ne yapıyoruz?"); saveHistory() }
    }

    private fun render(who: String, text: String) {
        chat.append("\n$who: $text\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun send() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText(""); render("SEN", text); history.add("user" to text); trimHistory(); saveHistory()
        val key = prefs.getString("api_key", "") ?: ""
        if (key.isBlank()) {
            val r = localReply(text); lastReply = r; render("DERİN", r); history.add("assistant" to r); trimHistory(); saveHistory(); return
        }
        status.text = "Derin düşünüyor…"
        thread {
            val r = callOpenAI(key)
            runOnUiThread { status.text = "İkinci zihin çevrimiçi."; lastReply = r; render("DERİN", r); history.add("assistant" to r); trimHistory(); saveHistory() }
        }
    }

    private fun localReply(text: String) = when {
        text.contains("selam", true) || text.contains("merhaba", true) -> "Buradayım. Söyle, neyi birlikte çözüyoruz?"
        text.contains("hafıza", true) -> "Bu sürüm konuşma geçmişini cihazda yerel olarak saklıyor."
        else -> "Mesajını aldım. Gerçek yapay zekâ yanıtları için ⚙ Ayarlar'dan API anahtarını ekleyebilirsin."
    }

    private fun callOpenAI(key: String): String = try {
        val c = URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = 60000; c.doOutput = true
        c.setRequestProperty("Authorization", "Bearer $key"); c.setRequestProperty("Content-Type", "application/json")
        val messages = JSONArray().put(JSONObject().put("role", "system").put("content", persona))
        history.takeLast(12).forEach { messages.put(JSONObject().put("role", it.first).put("content", it.second)) }
        val body = JSONObject().put("model", "gpt-4o-mini").put("messages", messages).put("temperature", 0.8)
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val raw = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        c.disconnect()
        if (code !in 200..299) return "API hatası ($code). API anahtarını ve hesabını kontrol et."
        JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
    } catch (e: Exception) { "Bağlantı kurulamadı. İnternet bağlantını ve API ayarlarını kontrol et." }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 8, 40, 0) }
        val keyInput = EditText(this).apply { hint = "OpenAI API anahtarı"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setText(prefs.getString("api_key", "")) }
        box.addView(keyInput)
        AlertDialog.Builder(this).setTitle("Derin Ayarları").setMessage("API anahtarı yalnızca bu cihazın uygulama alanında saklanır; APK içine gömülmez.").setView(box)
            .setPositiveButton("KAYDET") { _, _ -> prefs.edit().putString("api_key", keyInput.text.toString().trim()).apply(); status.text = "İkinci zihin çevrimiçi."; Toast.makeText(this, "API anahtarı kaydedildi.", Toast.LENGTH_SHORT).show() }
            .setNeutralButton("ANAHTARI SİL") { _, _ -> prefs.edit().remove("api_key").apply(); Toast.makeText(this, "API anahtarı silindi.", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("İPTAL", null).show()
    }

    private fun clearChat() {
        AlertDialog.Builder(this).setTitle("Sohbet temizlensin mi?").setMessage("Cihazda saklanan Derin konuşma geçmişi silinecek.")
            .setPositiveButton("SİL") { _, _ -> history.clear(); prefs.edit().remove("history").apply(); chat.text = ""; lastReply = ""; render("DERİN", "Temiz başladık kuzen.") }
            .setNegativeButton("İPTAL", null).show()
    }

    private fun saveHistory() {
        val a = JSONArray(); history.forEach { a.put(JSONObject().put("role", it.first).put("content", it.second)) }
        prefs.edit().putString("history", a.toString()).apply()
    }

    private fun loadHistory() {
        history.clear()
        try {
            val a = JSONArray(prefs.getString("history", "[]") ?: "[]")
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); history.add(o.getString("role") to o.getString("content")); render(if (o.getString("role") == "user") "SEN" else "DERİN", o.getString("content")); if (o.getString("role") == "assistant") lastReply = o.getString("content") }
        } catch (_: Exception) { prefs.edit().remove("history").apply() }
        trimHistory(); saveHistory()
    }

    private fun trimHistory() { while (history.size > 50) history.removeAt(0) }

    private fun speakLast() { if (lastReply.isNotBlank()) tts.speak(lastReply, TextToSpeech.QUEUE_FLUSH, null, "derin") }

    private fun startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.text = "Bu cihazda ses tanıma yok."; return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { status.text = "Dinliyorum…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(e: Int) { status.text = "Ses alınamadı."; recognizer?.destroy(); recognizer = null }
            override fun onResults(b: Bundle?) { val s = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull(); if (s != null) { input.setText(s); send() }; recognizer?.destroy(); recognizer = null }
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR"); putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_PROMPT, "Derin seni dinliyor…") }
        recognizer?.startListening(i)
    }

    override fun onInit(statusCode: Int) { if (statusCode == TextToSpeech.SUCCESS) { tts.language = Locale("tr", "TR"); tts.setSpeechRate(0.95f) } }
    override fun onDestroy() { recognizer?.destroy(); tts.shutdown(); super.onDestroy() }
}
