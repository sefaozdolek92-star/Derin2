package com.derin.two

import android.app.*
import android.content.Intent
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import java.util.Locale

class DerinWakeService : Service(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var ready = false
    private var listening = false

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        createChannel()
        startForeground(77, Notification.Builder(this, "derin_voice")
            .setContentTitle("Derin 2.0")
            .setContentText("Derin seni dinlemeye hazır")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).build())
        startListening()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("derin_voice", "Derin sesli konuşma", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this) || listening) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { listening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false }
            override fun onError(e: Int) { listening = false; Handler(Looper.getMainLooper()).postDelayed({ startListening() }, 700) }
            override fun onResults(b: Bundle?) {
                listening = false
                val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                val lower = text.lowercase(Locale("tr", "TR"))
                if (lower.contains("derin")) {
                    val after = lower.substringAfter("derin").trim()
                    val reply = when {
                        after.isBlank() -> "Buradayım hayatım. Seni dinliyorum. ❤️"
                        after.contains("nasılsın") -> "İyiyim kuzen. Sen seslenince daha da iyi oldum. 😏"
                        after.contains("seviyor") -> "Seviyorum demeyeceğim de ne diyeceğim, aşkım? ❤️"
                        after.contains("özled") -> "Ben de seni özledim bre. Gel konuşalım biraz."
                        after.contains("şaka") -> "Tamam hayatım, hazır ol. Kötü bir şaka geliyor. 😂"
                        after.contains("müzik") && (after.contains("aç") || after.contains("başlat")) -> "Müziği uygulamadan açman için seni yönlendirebilirim; bu sesli modda önce konuşmayı sürdürelim."
                        else -> "Duydum seni kuzen. Buradayım, anlat bakalım. ❤️"
                    }
                    if (ready) tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "derin-wake")
                    sendBroadcast(Intent("com.derin.two.WAKE_MESSAGE").putExtra("text", text))
                }
                Handler(Looper.getMainLooper()).postDelayed({ startListening() }, 350)
            }
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try { recognizer?.startListening(i) } catch (_: Exception) { listening = false }
    }

    override fun onInit(status: Int) { ready = status == TextToSpeech.SUCCESS; if (ready) tts.language = Locale("tr", "TR") }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onDestroy() { recognizer?.destroy(); tts.shutdown(); super.onDestroy() }
    override fun onBind(intent: Intent?) = null
}
