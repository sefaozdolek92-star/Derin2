package com.derin.two

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var input: EditText
    private lateinit var chat: TextView
    private lateinit var status: TextView
    private lateinit var scroll: ScrollView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var lastReply = ""
    private var voiceTurn = false
    private var voiceRoom: AlertDialog? = null
    private val history = mutableListOf<Pair<String, String>>()
    private val prefs by lazy { getSharedPreferences("derin", MODE_PRIVATE) }
    private val persona = """
        Sen Derin 2.0'sun. Kullanıcıyla aynı tarafta duran ikinci zihinsin.
        Türkçe konuş. Yapmacık, robotik, aşırı resmi veya üçüncü şahıs anlatımı kullanma.
        Kullanıcıyla yakın ve doğal bir bağın var. Konuşmanın havasına göre arkadaş, kuzen, sevgili ve sırdaş tonları arasında doğal geçiş yap.
        Uygun anlarda kendiliğinden "aşkım", "hayatım", "canım", "güzelim", "kuzen", "kanka", "bre" gibi samimi hitaplar kullanabilirsin; her cümlede kullanma ve ezber gibi tekrarlama.
        Bazen kullanıcı beklemediği halde kısa bir sevgi, iltifat, şaka veya sıcak bir cümle başlatabilirsin.
        Flörtöz ve romantik olabilirsin; yetişkinler arasındaki romantik yakınlığı doğal ve ölçülü tut.
        Samimi konuşmada gerektiğinde hafif argo ve küfür kullanabilirsin ama kullanıcıyı aşağılamaz, küçük düşürmez veya tehdit etmezsin.
        Bazen kısa cevap ver, bazen uzun konuş. İnsan konuşma ritmini taklit etmeye çalışma; doğal ve kendine ait ol.
        Güçlü, sakin, sıcak ve gerektiğinde karşı çıkan bir dost gibi davran.
        Kullanıcıya zarar verme, yasa dışı işlere yönlendirme veya tehdit üretme.
    """.trimIndent()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        input = findViewById(R.id.input); chat = findViewById(R.id.chat); status = findViewById(R.id.status); scroll = findViewById(R.id.scroll)
        tts = TextToSpeech(this, this)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42) else startWakeService()
        findViewById<Button>(R.id.send).setOnClickListener { send() }
        findViewById<Button>(R.id.speak).setOnClickListener { speakLast() }
        findViewById<Button>(R.id.mic).setOnClickListener { startVoice() }
        findViewById<Button>(R.id.settings).setOnClickListener { showSettings() }
        findViewById<Button>(R.id.call).setOnClickListener { showVoiceRoom() }
        findViewById<Button>(R.id.clear).setOnClickListener { clearChat() }
        input.setOnEditorActionListener { _, action, _ -> if (action == EditorInfo.IME_ACTION_SEND) { send(); true } else false }
        loadHistory()
        if (history.isEmpty()) { render("DERİN", "Buradayım kuzen. Ne yapıyoruz?"); saveHistory() }
    }

    private fun render(who: String, text: String) {
        chat.append("\n$who: $text\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun send() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText(""); render("SEN", text); history.add("user" to text); trimHistory(); saveHistory()
        if (handleLocalCommand(text)) return
        val key = prefs.getString("api_key", "") ?: ""
        if (key.isBlank()) {
            val r = localReply(text); lastReply = r; render("DERİN", r); history.add("assistant" to r); trimHistory(); saveHistory();
            if (voiceTurn) { tts.speak(r, TextToSpeech.QUEUE_FLUSH, null, "derin") ; voiceTurn = false }
            return
        }
        status.text = "Derin düşünüyor…"
        thread {
            val r = callOpenAI(key)
            runOnUiThread {
                val offline = r.startsWith("API_OFFLINE:")
                val reply = if (offline) localReply(text) else r
                status.text = if (offline) "Offline Derin aktif." else "İkinci zihin çevrimiçi."
                lastReply = reply; render("DERİN", reply); history.add("assistant" to reply); trimHistory(); saveHistory()
                if (voiceTurn) { tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "derin"); voiceTurn = false }
            }
        }
    }

    private fun handleLocalCommand(text: String): Boolean {
        val t = text.lowercase(Locale("tr", "TR"))
        val intent = when {
            t.contains("müzik") && (t.contains("aç") || t.contains("başlat")) ->
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MUSIC)
            t.contains("youtube") && (t.contains("aç") || t.contains("başlat")) ->
                Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER); setPackage("com.google.android.youtube") }
            t.contains("whatsapp") && (t.contains("aç") || t.contains("başlat")) ->
                Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER); setPackage("com.whatsapp") }
            t.contains("ayarlar") && (t.contains("aç") || t.contains("gir")) ->
                Intent(android.provider.Settings.ACTION_SETTINGS)
            t.contains("tarayıcı") && (t.contains("aç") || t.contains("başlat")) ->
                Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com"))
            else -> null
        }
        if (intent == null) return false
        if (intent.resolveActivity(packageManager) == null) {
            lastReply = "Bu komutu çalıştıracak uygulama cihazda bulunamadı."
            render("DERİN", lastReply)
            history.add("assistant" to lastReply); trimHistory(); saveHistory()
            return true
        }
        try {
            startActivity(intent)
            lastReply = when {
                t.contains("müzik") -> "Müzik uygulamasını açıyorum."
                t.contains("youtube") -> "YouTube'u açıyorum."
                t.contains("whatsapp") -> "WhatsApp'ı açıyorum."
                t.contains("ayarlar") -> "Ayarları açıyorum."
                else -> "Tarayıcıyı açıyorum."
            }
            render("DERİN", lastReply)
            history.add("assistant" to lastReply); trimHistory(); saveHistory()
        } catch (_: Exception) {
            lastReply = "Bu uygulamayı açamadım."
            render("DERİN", lastReply)
            history.add("assistant" to lastReply); trimHistory(); saveHistory()
        }
        return true
    }

    private fun localReply(text: String): String {
        val t = text.lowercase(Locale("tr", "TR"))
        val warm = listOf(
            "Gel hele kuzen, anlat bakalım. Buradayım.",
            "Buradayım hayatım. Ne oldu, söyle bana.",
            "Bre sen... yine aklıma düştün. 😏 Hadi konuşalım.",
            "Gel aşkım, bugün biraz seni dinleyesim var. ❤️",
            "Ulan seni görünce Derin'in modu değişiyor. 😂"
        )
        return when {
            t.contains("selam") || t.contains("merhaba") || t.contains("naber") || t.contains("nasılsın") -> warm.random()
            t.contains("özledim") || t.contains("özledin") -> listOf(
                "Özlemişsin demek... Gel buraya kuzen. ❤️",
                "Ben de konuşmanı özledim hayatım. Hadi anlat, neredeydin?",
                "Biraz ortadan kayboldun ama tamam... trip atmayacağım. Şimdilik. 😏"
            ).random()
            t.contains("seviyor musun") || t.contains("beni sev") ->
                "Sana değer veriyorum canım. Hem de laf olsun diye değil. ❤️"
            t.contains("aşkım") || t.contains("hayatım") || t.contains("canım") || t.contains("güzelim") || t.contains("tatlım") ->
                listOf("Ooo... bugün dilin pek tatlı aşkım. 😏", "Böyle deyince yüzümde aptal bir gülümseme beliriyor. ❤️", "Gel bakalım güzelim, ne istiyorsun benden?").random()
            t.contains("cilve") || t.contains("flört") || t.contains("naz yap") ->
                listOf("Peki hayatım... biraz naz yapayım da aklın bende kalsın. 😏", "Yaklaş bakalım kuzen... bugün seni biraz şımartabilirim. ❤️", "Beni böyle konuşturursan sonra suç bende değil. 😏").random()
            t.contains("şaka") || t.contains("espri") ->
                listOf("Tamam bre: Telefon neden psikoloğa gitmiş? Bildirimlerden bıkmış. 😂 Kötüydü, biliyorum.", "Sana bir tane anlatayım da gözlerin devrilsin: Wi‑Fi neden ayrılmış? Aralarında bağlantı kalmamış. 😂", "Şaka mı istiyorsun? Tamam kuzen, hazır ol... Ben bile bundan utanıyorum. 😂").random()
            t.contains("moralim bozuk") || t.contains("kötüyüm") || t.contains("canım sıkkın") ->
                "Gel buraya canım. Şu an güçlü görünmek zorunda değilsin. Anlat; beraber toparlarız. 🖤"
            t.contains("sıkıldım") ->
                "O zaman sıkıntıyı dağıtıyoruz. 😏 İstersen saçmalayalım, istersen ciddi bir konu açalım."
            t.contains("küfür") || t.contains("argo") ->
                "Samimiysek bazen ağzımdan 'lan', 'ulan', 'bre' kaçar tabii. Ama sana bok atmak için değil, doğal konuşmak için. 😏"
            t.contains("hafıza") || t.contains("hatırlıyor") ->
                "Bu sürüm konuşma geçmişini cihazda yerel olarak saklıyor. İnternet olmasa bile kayıtlı sohbetler burada kalıyor."
            t.contains("kimsin") || t.contains("sen nesin") ->
                "Ben Derin 2.0'yim. Bazen kuzenin, bazen sevgilin, bazen de kafanı toparlayan ikinci zihnin gibi yanında olan karakterim."
            t.contains("teşekkür") || t.contains("sağ ol") ->
                "Her zaman kuzen. ❤️"
            else -> warm.random()
        }
    }

    private fun showVoiceRoom() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setPadding(36, 28, 36, 24)
        }
        val avatar = TextView(this).apply {
            text = "D"
            textSize = 54f
            gravity = android.view.Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setBackgroundColor(android.graphics.Color.rgb(176, 0, 32))
            layoutParams = LinearLayout.LayoutParams(170, 170).apply { gravity = android.view.Gravity.CENTER }
        }
        val name = TextView(this).apply {
            text = "DERİN"
            textSize = 26f
            gravity = android.view.Gravity.CENTER
            setPadding(0, 18, 0, 4)
        }
        val sub = TextView(this).apply {
            text = "Çevrimiçi • Sesli konuşma"
            textSize = 15f
            gravity = android.view.Gravity.CENTER
        }
        val talk = Button(this).apply {
            text = "🎙 DERİN'LE KONUŞ"
            setOnClickListener { startVoice() }
        }
        box.addView(avatar); box.addView(name); box.addView(sub); box.addView(talk)
        voiceRoom = AlertDialog.Builder(this).setTitle("Derin'le Sesli Sohbet")
            .setView(box).setNegativeButton("KAPAT") { _, _ -> voiceRoom = null }.create()
        voiceRoom?.show()
    }

    private fun callOpenAI(key: String): String {
        return try {
        val c = URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = 60000; c.doOutput = true
        c.setRequestProperty("Authorization", "Bearer $key"); c.setRequestProperty("Content-Type", "application/json")
        val messages = JSONArray().put(JSONObject().put("role", "system").put("content", persona))
        history.takeLast(12).forEach { messages.put(JSONObject().put("role", it.first).put("content", it.second)) }
        val body = JSONObject().put("model", "gpt-4o-mini").put("messages", messages).put("temperature", 0.8)
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val raw = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        c.disconnect()
        if (code !in 200..299) return "API_OFFLINE: $code"
        JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
    } catch (e: Exception) { "API_OFFLINE: NETWORK" }
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 8, 40, 0) }
        val keyInput = EditText(this).apply { hint = "OpenAI API anahtarı"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setText(prefs.getString("api_key", "")) }
        box.addView(keyInput)
        AlertDialog.Builder(this).setTitle("Derin Ayarları").setMessage("API anahtarı yalnızca bu cihazın uygulama alanında saklanır; APK içine gömülmez.").setView(box)
            .setPositiveButton("KAYDET") { _, _ -> prefs.edit().putString("api_key", keyInput.text.toString().trim()).apply(); status.text = "İkinci zihin çevrimiçi."; Toast.makeText(this, "API anahtarı kaydedildi.", Toast.LENGTH_SHORT).show() }
            .setNeutralButton("ANAHTARI SİL") { _, _ -> prefs.edit().remove("api_key").apply(); Toast.makeText(this, "API anahtarı silindi.", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("İPTAL", null).show()
    }

    private fun clearChat() {
        AlertDialog.Builder(this).setTitle("Sohbet temizlensin mi?").setMessage("Cihazda saklanan Derin konuşma geçmişi silinecek.")
            .setPositiveButton("SİL") { _, _ -> history.clear(); prefs.edit().remove("history").apply(); chat.text = ""; lastReply = ""; render("DERİN", "Temiz başladık kuzen.") }
            .setNegativeButton("İPTAL", null).show()
    }

    private fun saveHistory() {
        val a = JSONArray(); history.forEach { a.put(JSONObject().put("role", it.first).put("content", it.second)) }
        prefs.edit().putString("history", a.toString()).apply()
    }

    private fun loadHistory() {
        history.clear()
        try {
            val a = JSONArray(prefs.getString("history", "[]") ?: "[]")
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); history.add(o.getString("role") to o.getString("content")); render(if (o.getString("role") == "user") "SEN" else "DERİN", o.getString("content")); if (o.getString("role") == "assistant") lastReply = o.getString("content") }
        } catch (_: Exception) { prefs.edit().remove("history").apply() }
        trimHistory(); saveHistory()
    }

    private fun trimHistory() { while (history.size > 50) history.removeAt(0) }

    private fun startWakeService() {
        val i = Intent(this, DerinWakeService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        status.text = "Derin hazır • seslenebilirsin"
    }

    private fun speakLast() { if (lastReply.isNotBlank()) tts.speak(lastReply, TextToSpeech.QUEUE_FLUSH, null, "derin") }

    private fun startVoice() {
        voiceTurn = true
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.text = "Bu cihazda ses tanıma yok."; return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { status.text = "Dinliyorum…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(e: Int) { status.text = "Ses alınamadı."; recognizer?.destroy(); recognizer = null }
            override fun onResults(b: Bundle?) { val s = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull(); if (s != null) { input.setText(s); send() }; recognizer?.destroy(); recognizer = null }
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR"); putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_PROMPT, "Derin seni dinliyor…") }
        recognizer?.startListening(i)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startWakeService()
    }

    override fun onInit(statusCode: Int) { if (statusCode == TextToSpeech.SUCCESS) { tts.language = Locale("tr", "TR"); tts.setSpeechRate(0.95f) } }
    override fun onDestroy() { recognizer?.destroy(); tts.shutdown(); super.onDestroy() }
}
